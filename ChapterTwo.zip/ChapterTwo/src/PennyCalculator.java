
public class PennyCalculator {
	 /*
	  * Assignment:  
	  *
	  *    Write a program to handle this task. You have 458 pennies in a jar. Calculate the number of dollars, 
	  *    quarters, dimes, nickels and pennies you will get from the bank. (The bank will give you the fewest coins 
	  *    possible.) Print out the number of dollars, quarters, dimes, nickels, and pennies you will get from the 
	  *    bank. Print out the total number of coins you will get. (Is a dollar bill a coin?)  
	  *    Print out each value on a different line.  
	 */
	public static void main(String[] args) {
		// TODO Write code here.
		
		
	}

}
