

/**
 * Calculates how many full cases can be filled with a given number of cans.
 * 
 * @author
 * @version
 * @date
 */
public class CaseCounter {
	/*
	 * SPECIFICATIONS:
	 * You have 457 cans and a case holds 12 cans. 
	 * Print out how many full cases you will have. 
	 * Print out how many cans are left over. 
	 * (Should 457 and 12 be constants or be typed into the code?)
	 */
	
	/**
	 * The main method where you will execute your code.
	 * @param args
	 */
	public static void main(String[] args) {
		
		//TODO Write Code.

	}

}
