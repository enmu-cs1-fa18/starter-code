
/**
 * Extracts a particular string from a longer one.
 * @author
 * @version
 * @date
 *
 */
public class StringExtractor {
	 /* 
	 * Assignment:
	 * 1. Using any of the string methods, write a sequence of commands that will extract 
	 *    characters from final String inputString = "The quick brown fox jumps over the lazy dog." to make
	 *    outputString = "Tempus fugit.". Then print inputString and outputString. Be sure to add some 
	 *    text so we know what has been done! 
	 *    
	 *    Correct any style, runtime, or compiler errors in the starter code.
	 */
	public static void main(String[] args) {
		final String inputString = "The quick brown fox jumps over the lazy dog.";
		final String outputString = "Tempus fugit";		
		
		// TODO Write code.
		
				
		
		
	}

}
