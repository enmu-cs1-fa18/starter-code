

public class ClassSec1 {

	public static void main(String[] args) {
		// Variables and Constants
		/*
		 * Variable:
		 * Declaring a variable:
		 * Variable initialization:
		 * Uninitialized variables default to ...
		 */
		
		/*
		 * Variable Number Types: (double, int)
		 *   When to use double:
		 *   Examples for double:
		 *   When to use int:
		 *   Examples for int:
		 */
		
		/*
		 * Variable naming conventions:
		 * Assignment statement:
		 * Constants:
		 */
		
		// Comments and Conventions:
		  
		/* Java Number Types (p. 40)
		 * http://www.coursesmart.com/bookshelf
		 */
		
	
		 
	}

}
